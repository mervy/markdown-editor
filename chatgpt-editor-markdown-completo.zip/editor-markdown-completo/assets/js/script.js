const textarea = document.getElementById('markdown');
const preview = document.getElementById('preview');

textarea.value = `# Editor Markdown com Preview 📝

## Funcionalidades principais

- Negrito e *itálico*
- Listas numeradas e não numeradas
- Blocos de código com syntax highlighting
- Links e imagens
- Citações
- Tabelas

---

### Exemplos de formatação

**Negrito** usando \`**texto**\`  
*Itálico* usando \`*texto*\`

---

### Lista não ordenada

- Item 1
- Item 2
  - Subitem 2.1
  - Subitem 2.2

### Lista ordenada

1. Primeiro
2. Segundo
3. Terceiro

---

### Código inline

Exemplo de código inline: \`console.log('Hello World!');\`

### Bloco de código Javascript

\`\`\`javascript
function saudacao(nome) {
  console.log(\`Olá, \${nome}!\`);
}

saudacao('Usuário');
\`\`\`

### Bloco de código PHP

\`\`\`php
class Database extends PDO
{
    function __construct()
    {
        parent::__construct(\'mysql:dbname=test;host=localhost\', \'root\', \'\');
        $this->setAttribute(PDO::ATTR_STATEMENT_CLASS, array(\'DBStatement\', array($this)));
    }
}

\`\`\`
---

### Citação

> Esta é uma citação importante no Markdown.

---

### Tabela

| Nome     | Idade | Cidade      |
|----------|-------|-------------|
| Ana      | 28    | São Paulo   |
| João     | 35    | Rio de Janeiro |
| Maria    | 22    | Curitiba    |

---

### Link e Imagem

[Viva o markdown](https://www.markdownguide.org/)  
![Placeholder](https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQpaVmOusItTUXFbnovJi9tY7H07EYzjrfbKg&s)

---

Divirta-se editando seu Markdown! 🚀
`;

// chama updatePreview depois para mostrar o conteúdo carregado
updatePreview();


// Atualiza o preview ao digitar
textarea.addEventListener('input', () => {
  updatePreview();
});

// Sincroniza scroll do preview com o textarea
textarea.addEventListener('scroll', () => {
  const scrollPercent = textarea.scrollTop / (textarea.scrollHeight - textarea.clientHeight);
  preview.scrollTop = scrollPercent * (preview.scrollHeight - preview.clientHeight);
});

function updatePreview() {
  const html = marked.parse(textarea.value);
  preview.innerHTML = html;
  document.querySelectorAll('#preview pre code').forEach(block => {
    hljs.highlightElement(block);
  });
}

function formatText(type) {
  const start = textarea.selectionStart;
  const end = textarea.selectionEnd;
  const selected = textarea.value.slice(start, end);
  let insert = "";

  switch (type) {
    case 'bold':
      insert = `**${selected || 'negrito'}**`;
      break;
    case 'italic':
      insert = `*${selected || 'itálico'}*`;
      break;
    case 'code':
      insert = `\`\`\`\n${selected || 'código'}\n\`\`\``;
      break;
    case 'ul':
      insert = selected
        ? selected.split('\n').map(line => `- ${line}`).join('\n')
        : '- item 1\n- item 2';
      break;
    case 'image':
      insert = `![alt](https://via.placeholder.com/150)`;
      break;
    case 'link':
      insert = `[${selected || 'texto do link'}](https://exemplo.com)`;
      break;
  }

  textarea.setRangeText(insert, start, end, 'end');
  updatePreview();
}

function saveHTML() {
  const blob = new Blob([preview.innerHTML], { type: 'text/html' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'preview.html';
  a.click();
}

function changeTheme(theme) {
  const themes = {
    light: 'https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.8.0/styles/github.min.css',
    dark: 'https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.8.0/styles/github-dark.min.css',
    'solarized-light': 'https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.8.0/styles/solarized-light.min.css'
  };

  const link = document.querySelector('link[href*="highlight.js"]');
  link.href = themes[theme];
}

// Carrega preview inicial
updatePreview();
